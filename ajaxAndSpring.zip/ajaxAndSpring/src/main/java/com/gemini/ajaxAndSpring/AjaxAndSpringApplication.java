package com.gemini.ajaxAndSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjaxAndSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjaxAndSpringApplication.class, args);
	}
}
